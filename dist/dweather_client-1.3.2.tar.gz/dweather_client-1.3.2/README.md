# dWeather-Python-Client

    cd dweather_client
    virtualenv .
    bin/pip3 install -r ../requirements.txt
    bin/python3 -m pytest tests

See `tests` directory for example usage.
